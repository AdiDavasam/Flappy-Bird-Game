public class Mechanics {
    int pipel, pipew, pipex, pipey, pipec;

}
